CREATE TABLE "FILEUPLOAD" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"FILENAME" VARCHAR2(255), 
	"FILEREALNAME" VARCHAR2(255), 
	"DOWNLOADCOUNT" NUMBER(*,0) DEFAULT 0, 
    CONSTRAINT "FILEUPLOAD_PK" PRIMARY KEY ("IDX")
);

delete from fileupload;
drop sequence fileupload_idx_seq;
create sequence fileupload_idx_seq;

select * from fileupload;

