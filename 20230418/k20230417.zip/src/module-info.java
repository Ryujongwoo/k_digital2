/**
 * 
 */
/**
 * @author TJ
 *
 */
module k20230417 {
	requires java.desktop;
}