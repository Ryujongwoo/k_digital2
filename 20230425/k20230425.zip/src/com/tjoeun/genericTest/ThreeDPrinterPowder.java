package com.tjoeun.genericTest;

//	재료로 Powder를 사용하는 3D 프린터, Powder 전용 프린터
public class ThreeDPrinterPowder {

	private Powder material;

	public Powder getMaterial() {
		return material;
	}
	public void setMaterial(Powder material) {
		this.material = material;
	}
	
}
