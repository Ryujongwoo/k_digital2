package com.tjoeun.genericTest;

//	3D 프린터 재료 - Plastic
public class Plastic {

	@Override
	public String toString() {
		return "Plastic";
	}

}
