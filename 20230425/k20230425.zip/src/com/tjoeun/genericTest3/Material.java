package com.tjoeun.genericTest3;

public interface Material {

}
