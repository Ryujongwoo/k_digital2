package com.tjoeun.genericTest3;

//	3D 프린터 재료 - Plastic
public class Plastic implements Material {

	@Override
	public String toString() {
		return "Plastic";
	}

}
