package com.tjoeun.genericTest3;

//	3D 프린터 재료 - Powder
public class Powder implements Material {

	@Override
	public String toString() {
		return "Powder";
	}

}
