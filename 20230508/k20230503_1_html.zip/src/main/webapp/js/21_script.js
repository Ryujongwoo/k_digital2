const myName = document.getElementById('my-name');
console.log(myName);
console.log(myName.innerText);
