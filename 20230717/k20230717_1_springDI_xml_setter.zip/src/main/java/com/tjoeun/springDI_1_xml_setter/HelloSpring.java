package com.tjoeun.springDI_1_xml_setter;

public class HelloSpring {

	public static void main(String[] args) {
		
		System.out.println("안녕 스프링");
		
	}
	
}
