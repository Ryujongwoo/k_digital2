package com.tjoeun.jpa.domain;

public enum Gender {

	BABY,
	MALE,
	FEMALE
	
}
