INSERT INTO memolist(NAME, PASSWORD, memo, ip) VALUES ('홍길동', '1111', '1등 입니다.', '162.168.100.001');



