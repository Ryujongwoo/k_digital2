$(() => {
	
	$('.delete').click(function () {
		// $(this).parent().slideUp('slow');
		$(this).parent().slideUp(1000, 'easeInOutBounce');
	});
	
	$('#view').click(function () {
		$('.pana').slideDown(1000, 'easeInOutBounce');
		// $('.pana').show(1000);
		// $('.pana').fadeIn(1000);
		// $('.pana').css('display', 'block');
	});
	
});


























