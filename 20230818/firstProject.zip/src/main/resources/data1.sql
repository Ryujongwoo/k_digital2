INSERT INTO article(title, content) VALUES ('홍길동', '천재');
INSERT INTO article(title, content) VALUES ('임꺽정', '바보');
INSERT INTO article(title, content) VALUES ('장길산', '멍청이');
INSERT INTO article(title, content) VALUES ('손오공', '원숭이');
INSERT INTO article(title, content) VALUES ('저팔계', '돼지');
INSERT INTO article(title, content) VALUES ('사오정', '나바아~~~~~ㅇ');