/**
 * 
 */
/**
 * @author TJ
 *
 */
module k20230411 {
	requires java.desktop;
}